/*;(function(factory) {
    "use strict";
    
	// CommonJS/Node.js
	if (typeof require === "function" && typeof exports === "object" && typeof module === "object")
    { 
        module.exports = factory();
    }
	else if (typeof define === "function")  // AMD/CMD/Sea.js
    {
		if (define.amd) { // for Require.js

			define(["editormd"], function(editormd) {
                factory()(editormd);
            });

		} else { // for Sea.js
			define(factory);
		}
	} 
	else
	{
        factory({})(window.editormd);
	}
    
}(function(exports) {
    
    return function (exports) {
        var lang = {
            name : "en",
            description : "A simple markdown doucment online editor.",
            toolbar : {
                undo             : "Undo(Ctrl+Z)",
                redo             : "Redo(Ctrl+Y)",
                bold             : "Bold",
                del              : "Strikethrough",
                italic           : "Italic",
                quote            : "Block quote",
                h1               : "Heading 1",
                h2               : "Heading 2",
                h3               : "Heading 3",
                h4               : "Heading 4",
                h5               : "Heading 5",
                h6               : "Heading 6",
                "list-ul"        : "Unordered list",
                "list-ol"        : "Ordered list",
                hr               : "Horizontal line",
                link             : "Link",
                picture          : "Picture",
                code             : "Code inline",
                "code-block-tab" : "Code block (Tab indent)",
                "code-block"     : "Code block (Multi-languages)",
                datetime         : "Datetime",
                watch            : "Unwatch",
                unwatch          : "Watch",
                preview          : "HTML Preview (Enter ESC exit)",
                fullscreen       : "Fullscreen (Enter ESC exit)",
                info             : "About " + exports.title
            }
        };
        
        exports.defaults.lang = lang;
    };
}));*/

(function(){
    var factory = function (exports) {
        var lang = {
            name : "en",
            description : "A simple markdown doucment online editor.",
            toolbar : {
                undo             : "Undo(Ctrl+Z)",
                redo             : "Redo(Ctrl+Y)",
                bold             : "Bold",
                del              : "Strikethrough",
                italic           : "Italic",
                quote            : "Block quote",
                h1               : "Heading 1",
                h2               : "Heading 2",
                h3               : "Heading 3",
                h4               : "Heading 4",
                h5               : "Heading 5",
                h6               : "Heading 6",
                "list-ul"        : "Unordered list",
                "list-ol"        : "Ordered list",
                hr               : "Horizontal line",
                link             : "Link",
                picture          : "Picture",
                code             : "Code inline",
                "code-block-tab" : "Code block (Tab indent)",
                "code-block"     : "Code block (Multi-languages)",
                datetime         : "Datetime",
                watch            : "Unwatch",
                unwatch          : "Watch",
                preview          : "HTML Preview (Enter ESC exit)",
                fullscreen       : "Fullscreen (Enter ESC exit)",
                info             : "About " + exports.title
            }
        };
        
        exports.defaults.lang = lang;
    };
    
	// CommonJS/Node.js
	if (typeof require === "function" && typeof exports === "object" && typeof module === "object")
    { 
        module.exports = factory();
    }
	else if (typeof define === "function")  // AMD/CMD/Sea.js
    {
		if (define.amd) { // for Require.js

			define(["editormd"], function(editormd) {
                factory(editormd);
            });

		} else { // for Sea.js
			define(function(require) {
                var editormd = require("../editormd");
                factory(editormd);
            });
		}
	} 
	else
	{
        factory(window.editormd);
	}
    
})();