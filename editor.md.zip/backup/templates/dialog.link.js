var linkDialog = function(){/*
<div class="{classPrefix}form">
	<label>{urlLabel}</label>
	<input type="text" class="{classPrefix}link-url" value="http://" />  
	<br/>
	<label>{urlTitleLabel}</label>
	<input type="text" class="{classPrefix}link-title" value="{title}" />
	<br/>
</div>*/};