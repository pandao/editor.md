CodeMirror.defineInitHook(function(cm) {
        cm.state.textStatistics = {charCount: 0, wordCount: 0};
        var updateStatisticsFunc = function(cm) {
          var charCount = 0;
          var wordCount = 0;
          cm.eachLine(function(line) {
            var text = line.text;
            charCount += text.length + 1;
            text = text.trim();
            if(text.length > 0) {
              wordCount += (text.match(/\s+/g)||[]).length + 1;
            }
          });
          cm.state.textStatistics.charCount = charCount;
          cm.state.textStatistics.wordCount = wordCount;
        };
        cm.on('inputRead', updateStatisticsFunc);
        cm.on('change', updateStatisticsFunc);
        updateStatisticsFunc(cm);
      });
      CodeMirror.defineExtension('charCount', function() {
        return this.state.textStatistics.charCount;
      });
      CodeMirror.defineExtension('wordCount', function() {
        return this.state.textStatistics.wordCount;
      });

	  
        cm.on('inputRead', updateStatisticsFunc);

		// or

		  editor.custom = {charCount: 0, wordCount: 0}; // <<-- need better code here...
      CodeMirror.defineExtension('charCount', function() {
        return this.custom.charCount;
      });
      CodeMirror.defineExtension('wordCount', function() {
        return this.custom.wordCount;
      });
      var countCharacters = function(cm) {
        var charCount = 0;
        var wordCount = 0;
        cm.eachLine(function(line) {
          var text = line.text;
          charCount += text.length + 1;
          text = text.trim();
          if(text.length > 0) {
            wordCount += (text.match(/\s+/g)||[]).length + 1;
          }
        });
        cm.custom.charCount = charCount;
        cm.custom.wordCount = wordCount;
      };
      countCharacters(editor);
      editor.on('change', countCharacters);